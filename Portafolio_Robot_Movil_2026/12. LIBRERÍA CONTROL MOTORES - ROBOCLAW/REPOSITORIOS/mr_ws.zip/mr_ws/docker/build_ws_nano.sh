#!/bin/bash
# Compila dentro del contenedor solo los paquetes que corren en la Nano (drivers). SLAM, Nav2 y la App
# corren en el PC o en la AGX Orin (Humble nativo). No se usa rosdep (instalaria paquetes apt de 18.04).
cd /root/robots_ws && source /opt/ros/humble/install/setup.bash && source /opt/mr_deps/install/setup.bash
colcon build --symlink-install --packages-select mr_interfaces mr_description mr_base mr_perception mr_bringup
