# mr_ws – Robot móvil diferencial SENA con ROS 2 Humble

Material de la transferencia de conocimiento (SENA, noviembre de 2026). Autor: Julián René Cháux Cedeño. Licencia Apache-2.0.

Hardware: 2 motorreductores Pololu (25D 47:1 con encoder de 48 CPR, o 37D con encoder de 64 CPR), RoboClaw 2x15A, Jetson Nano
(ROS 2 en Docker) o Jetson AGX Orin (ROS 2 nativo), cámara RGB USB, RPLidar A1 e Intel RealSense D435i.

## Paquetes

| Paquete | Contenido |
|---|---|
| `mr_interfaces` | `Order`, `OrderStatus`; servicios `GoTo`, `SavePoint`, `SubmitOrder`, `CancelOrder`; acciones `GoToStation`, `LoadProduct` |
| `mr_description` | URDF/Xacro con las mallas SolidWorks originales (`base_footprint → base_link → ruedas, laser, cámaras, d435i_link`), RViz2, plugins de Gazebo Fortress |
| `mr_base` | Driver ROS 2 del RoboClaw (protocolo Packet Serial propio, Python 3): `cmd_vel → SpeedAccelM1M2`, odometría por arcos, TF, `joint_states`, diagnóstico. Herramientas `mover` (avanzar/girar exacto y calibración 1 m / 360° / UMBmark) y `check_roboclaw`. Regla udev |
| `mr_sim` | Robot virtual sin GPU: emulador del RoboClaw por puerto serie virtual (mismo protocolo), lidar 2D por trazado de rayos, mundo `laboratorio` (PNG + SDF) |
| `mr_perception` | Cámara USB con OpenCV (sin cv_bridge), útil en la Jetson Nano |
| `mr_bringup` | `robot.launch.py` (real), `virtual.launch.py`, `gazebo.launch.py`, `slam.launch.py`, `navigation.launch.py`, `rviz.launch.py`; parámetros de Nav2, slam_toolbox, RoboClaw; mapa y estaciones |
| `mr_navigation` | `station_manager` (puntos con nombre, `/mr/go_to`, `/mr/go_to_station`, `/mr/save_point`) y órdenes `ir_a`, `recorrido`, `guardar_punto`, `estaciones` |
| `mr_logistics` | `mission_manager` (pedido → cobot → estación) y `web_app` (Flask: pedidos, mapa, teleoperación desde el celular); CLI `pedido` |
| `mr_cobot_bridge` | `cobot_station` en el equipo del JetCobot: recibe el pedido, ubica la bandeja (ArUco) y ejecuta `/jc/pick_place` de `jc_ws` |
| `docker/` | `Dockerfile.nano`, `run_nano.sh`, `build_ws_nano.sh` (ROS 2 Humble en la Jetson Nano) |
| `systemd/` | `mr-robot.service` (arranque automático de los drivers) |

## Uso: reserva + espacio de trabajo común `~/robots_ws`

Este archivo es la **reserva** del curso. No se compila tal cual: se descomprime en `~/mr_reserva` y los paquetes se
incorporan paso a paso al espacio de trabajo común **`~/robots_ws`**, el mismo que usa la celda del cobot (paquetes
`jc_*`). Se usa en el PC y en el computador del robot (DA-9.1).

```bash
# DA-9.1: reserva, dependencias y espacio de trabajo
mkdir -p ~/mr_reserva && cd ~/mr_reserva
REPO=https://raw.githubusercontent.com/jchauxdev/JetCobot/main
wget $REPO/Portafolio_Robot_Movil_2026/mr_ws.zip && unzip mr_ws.zip
rosdep install --from-paths ~/mr_reserva/mr_ws/src --ignore-src -r -y --skip-keys "jc_interfaces"
mkdir -p ~/robots_ws/src && cd ~/robots_ws && colcon build
# En cada documento (Paso 0), por ejemplo:
cp -r ~/mr_reserva/mr_ws/src/mr_base ~/mr_reserva/mr_ws/src/mr_sim ~/robots_ws/src/
cd ~/robots_ws && colcon build --symlink-install --packages-select mr_base mr_sim && source install/setup.bash
```

| Documento | Se incorpora a `~/robots_ws` |
|---|---|
| DA-9.1 | `mr_base`, `mr_sim` (y la regla udev) |
| DA-11.2 (Jetson Nano) | `docker/` y `mr_base` (en la Nano: `mr_description` y `mr_bringup` en el DA-12.1, `mr_perception` en el DA-15.1) |
| DA-12.1 | `mr_description`, `mr_bringup` |
| DA-15.1 | `mr_perception` |
| DA-18.1 | `mr_interfaces`, `mr_navigation` |
| DA-19.1 | `mr_logistics` |
| DA-21.1 | `mr_cobot_bridge` (requiere `jc_interfaces` en el mismo espacio de trabajo) |

`systemd/mr-robot.service` se copia directamente desde la reserva (DA-13.3).

## Compilación completa de una vez (instructor / respaldo)

```bash
mkdir -p ~/robots_ws/src && cp -r ~/mr_reserva/mr_ws/src/* ~/robots_ws/src/ && cd ~/robots_ws
colcon build --symlink-install --packages-skip mr_cobot_bridge   # mr_cobot_bridge solo si están los paquetes jc_*
source install/setup.bash
sudo cp src/mr_base/udev/99-mr-robot.rules /etc/udev/rules.d/ && sudo udevadm control --reload-rules && sudo udevadm trigger
```
Jetson Nano: copie `docker/` a `~/robots_ws/docker` (DA-11.2).

## Uso rápido

```bash
ros2 launch mr_bringup virtual.launch.py               # robot virtual (o robot.launch.py en el robot real)
ros2 run mr_base mover avanzar 1.0                     # avanza 1 m exacto según la odometría
ros2 run mr_base mover lineal 1.0 --config <yaml>      # calibración: pide la distancia medida con cinta
ros2 launch mr_bringup slam.launch.py rviz:=true       # mapeo; guardar: ros2 run nav2_map_server map_saver_cli -f ~/mapas/lab
ros2 launch mr_bringup navigation.launch.py map:=$HOME/mapas/lab.yaml
ros2 run mr_navigation ir_a estacion_A                 # ir al punto con nombre
ros2 launch mr_logistics logistica.launch.py           # App web en http://<ip>:8080
```

Celda integrada con el cobot (DA-21.1): el robot usa el espacio de nombres `mr` (sus TF y `robot_description` no chocan con los del
JetCobot, que también tiene `base_link`):
```bash
ros2 launch mr_bringup robot.launch.py namespace:=mr          # o virtual.launch.py namespace:=mr
ros2 launch mr_bringup navigation.launch.py namespace:=mr
ros2 launch mr_logistics logistica.launch.py namespace:=mr
# en el equipo del cobot, con la celda (paquetes jc_* en ~/robots_ws) en marcha:
ros2 launch mr_cobot_bridge cobot_station.launch.py
```

## Validación previa (entorno ROS 2 Humble, Nav2 1.1.18, slam_toolbox 2.6.10)

Resultados en el robot virtual (emulador del RoboClaw con geometría real distinta de la nominal: D = 87,5 mm, b = 209 mm):
- Calibración: con valores de hoja de datos el robot recorre 0,985 m cuando la odometría dice 1,013 m (+2,9 %) y gira 348,8° cuando dice 361,7°.
  Tras una iteración: `ticks_per_meter` 7953 → 8180 y `wheel_separation` 0,2016 → 0,2090 m; error residual 0,0 mm en 1 m y 0,04° en 360°.
- `mover avanzar`: error de parada ≤ 2,6 mm en 0,5–2 m; `mover girar`: ≤ 0,6° en 90–360°.
- Mapa slam_toolbox (recorrido de 40 m, deslizamiento 1 %): error medio 1,4 cm frente a la verdad terreno, P95 4,0 cm.
- Nav2 punto a punto: 6/6 metas logradas; error real medio 4,5 cm (máx. 6,8 cm), orientación ±4°.
- Logística extremo a extremo (App web → robot → cobot simulado con MoveIt 2 → estación): 2 pedidos COMPLETADOS en cola.
- No validado en el entorno de pruebas: hardware físico (RoboClaw, RPLidar, RealSense), Gazebo con lidar/cámara (requiere GPU),
  y la imagen Docker de la Nano (requiere la Jetson).
