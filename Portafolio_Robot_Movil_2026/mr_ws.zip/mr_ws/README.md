# mr_ws – Robot móvil diferencial SENA con ROS 2 Humble

Material de la transferencia de conocimiento (SENA, noviembre de 2026). Autor: Julián René Cháux Cedeño. Licencia Apache-2.0.
Actualiza a ROS 2 Humble la versión anterior del curso (ROS Melodic: `roboclaw_ros`, `gmapping`, `move_base`, `amcl`, ROS-Mobile).

Hardware: 2 motorreductores Pololu (25D 47:1 con encoder de 48 CPR, o 37D con encoder de 64 CPR), RoboClaw 2x15A, Jetson Nano
(ROS 2 en Docker) o Jetson AGX Orin (ROS 2 nativo), cámara RGB USB, RPLidar A1 e Intel RealSense D435i.

## Paquetes

| Paquete | Contenido |
|---|---|
| `mr_interfaces` | `Order`, `OrderStatus`; servicios `GoTo`, `SavePoint`, `SubmitOrder`, `CancelOrder`; acciones `GoToStation`, `LoadProduct` |
| `mr_description` | URDF/Xacro con las mallas SolidWorks originales (`base_footprint → base_link → ruedas, laser, cámaras, d435i_link`), RViz2, plugins de Gazebo Fortress |
| `mr_base` | Driver ROS 2 del RoboClaw (protocolo Packet Serial propio, Python 3): `cmd_vel → SpeedAccelM1M2`, odometría por arcos, TF, `joint_states`, diagnóstico. Herramientas `mover` (avanzar/girar exacto y calibración 1 m / 360° / UMBmark) y `check_roboclaw`. Regla udev |
| `mr_sim` | Robot virtual sin GPU: emulador del RoboClaw por puerto serie virtual (mismo protocolo), lidar 2D por trazado de rayos, mundo `laboratorio` (PNG + SDF) |
| `mr_perception` | Cámara USB con OpenCV (sin cv_bridge), útil en la Jetson Nano |
| `mr_bringup` | `robot.launch.py` (real), `virtual.launch.py`, `gazebo.launch.py`, `slam.launch.py`, `navigation.launch.py`, `rviz.launch.py`; parámetros de Nav2, slam_toolbox, RoboClaw; mapa y estaciones |
| `mr_navigation` | `station_manager` (puntos con nombre, `/mr/go_to`, `/mr/go_to_station`, `/mr/save_point`) y órdenes `ir_a`, `recorrido`, `guardar_punto`, `estaciones` |
| `mr_logistics` | `mission_manager` (pedido → cobot → estación) y `web_app` (Flask: pedidos, mapa, teleoperación desde el celular); CLI `pedido` |
| `mr_cobot_bridge` | `cobot_station` en el equipo del JetCobot: recibe el pedido, ubica la bandeja (ArUco) y ejecuta `/jc/pick_place` de `jc_ws` |
| `docker/` | `Dockerfile.nano`, `run_nano.sh`, `build_ws_nano.sh` (ROS 2 Humble en la Jetson Nano) |
| `systemd/` | `mr-robot.service` (arranque automático de los drivers) |

## Instalación (PC Ubuntu 22.04 o Jetson AGX Orin con JetPack 6.2)

```bash
sudo apt install ros-humble-navigation2 ros-humble-nav2-bringup ros-humble-slam-toolbox ros-humble-rplidar-ros \
  ros-humble-teleop-twist-keyboard ros-humble-xacro ros-humble-joint-state-publisher-gui python3-serial python3-flask
mkdir -p ~/mr_ws && cp -r src ~/mr_ws/ && cd ~/mr_ws
rosdep install --from-paths src --ignore-src -r -y --skip-keys "jc_interfaces"
colcon build --symlink-install --packages-skip mr_cobot_bridge     # mr_cobot_bridge solo donde esté jc_ws
source install/setup.bash
sudo cp src/mr_base/udev/99-mr-robot.rules /etc/udev/rules.d/ && sudo udevadm control --reload-rules && sudo udevadm trigger
```
Jetson Nano: ver `docker/` y DA-10.2.

## Uso rápido

```bash
ros2 launch mr_bringup virtual.launch.py               # robot virtual (o robot.launch.py en el robot real)
ros2 run mr_base mover avanzar 1.0                     # avanza 1 m exacto según la odometría
ros2 run mr_base mover lineal 1.0 --config <yaml>      # calibración: pide la distancia medida con cinta
ros2 launch mr_bringup slam.launch.py rviz:=true       # mapeo; guardar: ros2 run nav2_map_server map_saver_cli -f ~/mapas/lab
ros2 launch mr_bringup navigation.launch.py map:=$HOME/mapas/lab.yaml
ros2 run mr_navigation ir_a estacion_A                 # ir al punto con nombre
ros2 launch mr_logistics logistica.launch.py           # App web en http://<ip>:8080
```

Celda integrada con el cobot (DA-20): el robot usa el espacio de nombres `mr` (sus TF y `robot_description` no chocan con los del
JetCobot, que también tiene `base_link`):
```bash
ros2 launch mr_bringup robot.launch.py namespace:=mr          # o virtual.launch.py namespace:=mr
ros2 launch mr_bringup navigation.launch.py namespace:=mr
ros2 launch mr_logistics logistica.launch.py namespace:=mr
# en el equipo del cobot, con la celda jc_ws en marcha:
ros2 launch mr_cobot_bridge cobot_station.launch.py
```

## Validación previa (entorno ROS 2 Humble, Nav2 1.1.18, slam_toolbox 2.6.10)

Resultados en el robot virtual (emulador del RoboClaw con geometría real distinta de la nominal: D = 87,5 mm, b = 209 mm):
- Calibración: con valores de hoja de datos el robot recorre 0,985 m cuando la odometría dice 1,013 m (+2,9 %) y gira 348,8° cuando dice 361,7°.
  Tras una iteración: `ticks_per_meter` 7953 → 8180 y `wheel_separation` 0,2016 → 0,2090 m; error residual 0,0 mm en 1 m y 0,04° en 360°.
- `mover avanzar`: error de parada ≤ 2,6 mm en 0,5–2 m; `mover girar`: ≤ 0,6° en 90–360°.
- Mapa slam_toolbox (recorrido de 40 m, deslizamiento 1 %): error medio 1,4 cm frente a la verdad terreno, P95 4,0 cm.
- Nav2 punto a punto: 6/6 metas logradas; error real medio 4,5 cm (máx. 6,8 cm), orientación ±4°.
- Logística extremo a extremo (App web → robot → cobot simulado con MoveIt 2 → estación): 2 pedidos COMPLETADOS en cola.
- No validado en el entorno de pruebas: hardware físico (RoboClaw, RPLidar, RealSense), Gazebo con lidar/cámara (requiere GPU),
  y la imagen Docker de la Nano (requiere la Jetson).
