# Cambios del material de reserva `mr_ws`

Cada vez que se publica una versión nueva de `mr_ws.zip` se anota aquí. Para actualizar su copia vea el DA-9.1
(«Actualizar la reserva»).

## 2026-11-02
- Espacio de trabajo común `~/robots_ws` (PC y robot, compartido con el cobot); la reserva se descomprime en `~/mr_reserva`.
- `docker/run_nano.sh`: con argumentos ejecuta el comando con ROS 2 y `robots_ws` cargados.
- `docker/build_ws_nano.sh`: compila los paquetes que ya estén en `src/` (incorporación paso a paso en la Nano).
- Referencias de documentos de apoyo actualizadas a la numeración 8–21.
