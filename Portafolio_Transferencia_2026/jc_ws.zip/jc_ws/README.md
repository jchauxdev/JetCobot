# jc_ws – Celda robótica colaborativa JetCobot + visión artificial + ROS 2 Humble

Material de la transferencia de conocimiento (SENA, 03–06/11/2026). Autor: Julián René Cháux Cedeño. Licencia Apache-2.0.

## Paquetes

| Paquete | Contenido |
|---|---|
| `jc_interfaces` | Mensajes `DetectedObject(Array)`, servicios `MoveToPose`, `MoveToNamed`, `SetGripper`, acciones `Countdown`, `PickPlace` |
| `jc_description` | URDF/Xacro del JetCobot (cinemática del myCobot 280 JN), pinza, TCP, cámara en mano, ros2_control, Gazebo |
| `jc_moveit_config` | SRDF, KDL, OMPL, límites y controladores para MoveIt 2 |
| `jc_motion` (C++) | `motion_server`, `pose_goal_demo`, `trajectory_client` |
| `jc_driver` | `jetcobot_bridge` (ROS 2 ↔ pymycobot), `joint_state_follower`, `check_robot`, regla udev |
| `jc_bringup` | `mock.launch.py`, `sim.launch.py` (Gazebo Fortress), `real.launch.py`; mundos y configuración de la celda |
| `jc_vision` | `camera_node`, `color_shape_detector`, `aruco_detector`, `yolo_detector`, `handeye_calibration` |
| `jc_apps` | Nodos didácticos, `kinematics.py` (FK/IK), `trajectory_demo`, `square_demo`, `fk_check`, `pick_place_node`, `celda.launch.py` |
| `practicas/` | Scripts OpenCV (`dia2_vision`, DA-08) y PyTorch/YOLO (`dia3_deep_learning`, DA-11) sin ROS |
| `tools/` | `synthetic_camera.py`, `fake_detections.py`, `handeye_auto.py` (pruebas sin GPU / sin robot) |

## Uso: reserva + construcción paso a paso

Este archivo es la **reserva** del curso. No se copia completo al workspace: se descomprime en `~/jc_reserva` y
cada documento de apoyo incorpora al espacio de trabajo común `~/robots_ws` solo lo que usa (Paso 0 de cada DA).
`~/robots_ws` es el mismo espacio de trabajo del robot móvil (paquetes `mr_*`, reserva `mr_ws.zip`).

```bash
# DA-02: reserva, dependencias y workspace vacío
mkdir -p ~/jc_reserva && unzip jc_ws.zip -d ~/jc_reserva
rosdep install --from-paths ~/jc_reserva/jc_ws/src --ignore-src -r -y
mkdir -p ~/robots_ws/src && cd ~/robots_ws && colcon build

# En cada DA (ejemplo DA-05):
cp -r ~/jc_reserva/jc_ws/src/jc_moveit_config ~/jc_reserva/jc_ws/src/jc_motion ~/jc_reserva/jc_ws/src/jc_bringup ~/robots_ws/src/
cd ~/robots_ws && colcon build --symlink-install --packages-select jc_moveit_config jc_motion jc_bringup && source install/setup.bash
```

| Documento | Se incorpora | Equipo |
|---|---|---|
| DA-02 | (workspace vacío + reserva) | PC |
| DA-03 | `jc_interfaces`, `jc_apps`; en el Paso 7 `jc_description` (+ pruebas de `jc_apps`) | PC |
| DA-05 | `jc_moveit_config`, `jc_motion`, `jc_bringup` | PC |
| DA-06 | `tools/` | PC |
| DA-08 | `practicas/dia2_vision` | PC |
| DA-09 | `jc_vision` (+ pruebas de `jc_vision`) | PC |
| DA-11 | `practicas/dia3_deep_learning` | PC |
| DA-13 | todo lo de la Parte A (7 paquetes, `practicas/`, `tools/`) + `mi_celda` desde Git | Jetson |
| DA-14 | `jc_driver` | Jetson |

Para restaurar un archivo dañado: `cp ~/jc_reserva/jc_ws/src/<paquete>/<archivo> ~/robots_ws/src/<paquete>/<archivo>`.
No compile dentro de `~/jc_reserva`.

## Compilación completa de una vez (instructor / respaldo)

```bash
mkdir -p ~/robots_ws && cp -r src practicas tools ~/robots_ws/ && cd ~/robots_ws
rosdep install --from-paths src --ignore-src -r -y
colcon build --symlink-install && source install/setup.bash
colcon test --packages-select jc_vision jc_apps && colcon test-result --verbose
```

## Lanzamientos principales

```bash
ros2 launch jc_description display.launch.py                 # modelo en RViz2
ros2 launch jc_bringup mock.launch.py                        # MoveIt 2 sin física
ros2 launch jc_bringup sim.launch.py                         # Gazebo Fortress + MoveIt 2
ros2 launch jc_bringup real.launch.py port:=/dev/ttyUSB0 camera:=true handeye:=true
ros2 launch jc_apps celda.launch.py mode:=sim detector:=clasico auto_sort:=true
```

## Organización y ¿dónde se ejecuta? (PC ↔ Jetson)

`robots_ws` se construye en **ambos** equipos (en el PC paso a paso durante la Parte A; en la Jetson en DA-13 y DA-14). La transferencia se divide en dos partes:

- **Parte A – Simulación en el PC** (Días 1–3, DA-02 a DA-12): todo corre en el PC, sin Jetson ni robot.
- **Parte B – Robot real con la Jetson** (Días 3–4, DA-13 a DA-17): la Jetson ejecuta los nodos junto al robot y el PC visualiza y comanda por la red.

- **Simulación** (mock/Gazebo, Parte A): todo en el PC. Use `export ROS_LOCALHOST_ONLY=1` para no interferir con otros equipos ni con la Jetson (DA-02).
- **Robot real**: en la Jetson (por SSH + tmux) corren el driver, la cámara, MoveIt 2, la visión y la aplicación:
  `ros2 launch jc_bringup real.launch.py camera:=true handeye:=true rviz:=false compress:=true`.
  En el PC (misma red, mismo `ROS_DOMAIN_ID`): `ros2 launch jc_moveit_config rviz.launch.py`,
  `ros2 run rqt_image_view rqt_image_view /jc/debug_image/compressed` y los nodos/órdenes en desarrollo.
- Un `ROS_DOMAIN_ID` por pareja Jetson–PC; relojes sincronizados con `chrony`. Detalles en DA-13, sección 2.3 y Paso 8.

## Validación previa (entorno ROS 2 Humble, MoveIt 2.5.9, Gazebo Fortress 6.16)

- 8/8 paquetes compilan; 7/7 pruebas unitarias aprobadas.
- Mock, Gazebo y puente del robot (pymycobot simulado): trayectorias, servicios, cancelación → éxito.
- Pick & place integrado en Gazebo (visión con cámara sintética → MoveIt → física): cubo depositado a 4,7 mm del objetivo.
- No validado en el entorno de pruebas: render de cámara de Gazebo (requiere GPU), TensorRT y el JetCobot físico.

Notas: el puerto/baudios por defecto (`/dev/ttyUSB0`, 1 000 000) son los de las apps del instructor; verifique su unidad con
`ros2 run jc_driver check_robot`. Los valores nominales de TCP (95 mm) y cámara deben ajustarse con medidas reales y
calibración mano-ojo (ver DA-04, DA-14, DA-09 y DA-16).
