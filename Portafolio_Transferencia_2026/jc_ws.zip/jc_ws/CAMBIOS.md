# Cambios del material de reserva `jc_ws`

Cada vez que se publica una versión nueva de `jc_ws.zip` se anota aquí. Para actualizar su copia vea el DA-02
(«Actualizar la reserva»).

## 2026-11-02
- Espacio de trabajo común `~/robots_ws` (compartido con el robot móvil); la reserva se descomprime en `~/jc_reserva`.
- `jc_vision/handeye_calibration`: el resultado se guarda por defecto en `~/robots_ws/handeye_result.yaml`.
